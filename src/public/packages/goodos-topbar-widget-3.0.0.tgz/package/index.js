import {
  Fragment,
  cloneElement,
  createElement,
  isValidElement,
} from "react";
import { createPortal } from "react-dom";

export const GOODOS_TOPBAR_WIDGET_VERSION = "3.0.0";

function classes(...values) {
  return values.filter(Boolean).join(" ");
}

function buildStructuredTopBar({
  appName,
  workspaceLabel,
  brandIcon,
  leadingControl,
  search,
  actions,
  controls,
  onBrandClick,
  className,
  brandClassName,
  brandMarkClassName,
  workspaceClassName,
  searchClassName,
  style,
}) {
  if (!appName) {
    throw new Error(
      "GoodOSTopBarWidget requires either children or an appName.",
    );
  }

  return createElement(
    "header",
    {
      className: classes("goodos-topbar", className),
      "data-goodos-topbar": "",
      style,
    },
    createElement(
      "div",
      {
        className: "goodos-topbar__identity",
        "data-goodos-topbar-identity": "",
      },
      leadingControl,
      createElement(
        "button",
        {
          type: "button",
          className: classes("goodos-topbar__brand", brandClassName),
          "data-goodos-topbar-brand": "",
          onClick: onBrandClick,
          "aria-label": `Open ${appName} home`,
        },
        createElement(
          "span",
          {
            className: classes(
              "goodos-topbar__brand-mark",
              brandMarkClassName,
            ),
            "data-goodos-topbar-brand-mark": "",
            "aria-hidden": "true",
          },
          brandIcon,
        ),
        createElement("span", null, appName),
      ),
      createElement(
        "span",
        {
          className: classes("goodos-topbar__workspace", workspaceClassName),
          "data-goodos-topbar-workspace": "",
          title: workspaceLabel,
        },
        workspaceLabel,
      ),
    ),
    createElement(
      "div",
      {
        className: classes("goodos-topbar__search", searchClassName),
        "data-goodos-topbar-search": "",
      },
      search,
    ),
    createElement(
      "nav",
      {
        className: "goodos-topbar__actions",
        "data-goodos-topbar-actions": "",
        "aria-label": `${appName} actions`,
      },
      actions,
    ),
    createElement(
      "nav",
      {
        className: "goodos-topbar__controls",
        "data-goodos-topbar-controls": "",
        "aria-label": "Universal controls",
      },
      controls,
    ),
  );
}

/**
 * Canonical GoodOS suite top-bar shell.
 *
 * It supports the current structured API and the legacy children API so every
 * product can migrate without losing application-owned behavior. The portal
 * keeps the bar outside product overflow and stacking contexts; the spacer
 * reserves the shared responsive bar height.
 */
export function GoodOSTopBarWidget(props) {
  const bar = props.children ?? buildStructuredTopBar(props);
  const instrumentedBar = isValidElement(bar)
    ? cloneElement(bar, {
        "data-goodos-topbar-widget-version": GOODOS_TOPBAR_WIDGET_VERSION,
      })
    : bar;
  const mountedBar =
    typeof document === "undefined"
      ? instrumentedBar
      : createPortal(instrumentedBar, document.body);

  return createElement(
    Fragment,
    null,
    createElement("div", {
      className: "goodos-topbar-widget__spacer",
      "data-goodos-topbar-spacer": "",
      "data-goodos-topbar-widget-version": GOODOS_TOPBAR_WIDGET_VERSION,
      "aria-hidden": "true",
    }),
    mountedBar,
  );
}
