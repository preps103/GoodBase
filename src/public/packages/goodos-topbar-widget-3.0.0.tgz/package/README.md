# GoodOS top-bar widget

`@goodos/topbar-widget` is the single React shell used by authenticated
GoodApps. It owns viewport placement, the responsive spacer, structural zone
order, and widget versioning. Each product continues to own its icon, search,
actions, notifications, help, account data, and theme tokens.

Applications must also load the canonical structural stylesheet:

```html
<link rel="stylesheet" href="https://base.goodos.app/backend-topbar.css">
```

The structured API is preferred:

```tsx
import { GoodOSTopBarWidget } from "@goodos/topbar-widget";

<GoodOSTopBarWidget
  appName="GoodFleet"
  workspaceLabel="Fleet Workspace"
  brandIcon={<FleetIcon />}
  search={<FleetSearch />}
  actions={<FleetActions />}
  controls={<FleetControls />}
/>
```

The children API remains supported while older product headers are migrated:

```tsx
<GoodOSTopBarWidget>
  <header className="goodos-topbar" data-goodos-topbar>
    {/* canonical identity, search, actions, and controls zones */}
  </header>
</GoodOSTopBarWidget>
```

Product code may override `--goodos-topbar-*` color tokens. Structural sizes,
zone order, and placement belong to the shared GoodBase stylesheet.
