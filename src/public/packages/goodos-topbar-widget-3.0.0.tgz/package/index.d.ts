import type { CSSProperties, ReactNode } from "react";

export declare const GOODOS_TOPBAR_WIDGET_VERSION = "3.0.0";

interface SharedProps {
  className?: string;
  style?: CSSProperties;
}

export interface GoodOSTopBarChildrenProps extends SharedProps {
  children: ReactNode;
  appName?: never;
  workspaceLabel?: never;
  brandIcon?: never;
  leadingControl?: never;
  search?: never;
  actions?: never;
  controls?: never;
  onBrandClick?: never;
  brandClassName?: never;
  brandMarkClassName?: never;
  workspaceClassName?: never;
  searchClassName?: never;
}

export interface GoodOSTopBarStructuredProps extends SharedProps {
  children?: never;
  appName: string;
  workspaceLabel: string;
  brandIcon: ReactNode;
  leadingControl?: ReactNode;
  search: ReactNode;
  actions?: ReactNode;
  controls: ReactNode;
  onBrandClick?: () => void;
  brandClassName?: string;
  brandMarkClassName?: string;
  workspaceClassName?: string;
  searchClassName?: string;
}

export declare function GoodOSTopBarWidget(
  props: GoodOSTopBarChildrenProps | GoodOSTopBarStructuredProps,
): ReactNode;
