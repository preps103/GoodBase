# GoodOS UI widget

This package is the authoritative React UI contract for the GoodOS top bar and
centralized login surface. GoodBase owns authentication and provider
availability. Product applications supply branding, application-specific
authorization, and callbacks that invoke GoodBase.

Use `GoodOSLoginShell` for the two-panel page structure and
`GoodOSLoginWidget` for the authentication panel. Do not fork the panel markup
or authentication behavior inside product repositories.

Product repositories keep a vendored snapshot so production builds remain
deterministic and do not require registry access. From the GoodBase repository,
run `npm run auth:widget:check` to detect drift or
`npm run auth:widget:sync` to refresh all available sibling
repositories from this authoritative source.
